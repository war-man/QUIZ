# App thi bằng lái xe máy A1
Use Retrofit2 + Okhttp3 + MVP structure

> **Task in app**
- Làm thử đề
- Ôn lý thuyết
- Học sa hình
- Học biển báo
- Giới thiệu + kinh nghiệm thi thực hành
- Mức xử phạt

> Phát triển ứng dụng di động D15-PTIT-2019
