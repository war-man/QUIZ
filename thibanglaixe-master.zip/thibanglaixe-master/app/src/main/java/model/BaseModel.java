package model;

public class BaseModel {
}
