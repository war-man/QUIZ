package presenter;

public interface TopicPresenter {
    public void getListTopics();
}
