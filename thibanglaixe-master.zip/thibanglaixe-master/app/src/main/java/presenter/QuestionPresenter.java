package presenter;

public interface QuestionPresenter {
    void getListQuestion(String task, String idDe);

}
