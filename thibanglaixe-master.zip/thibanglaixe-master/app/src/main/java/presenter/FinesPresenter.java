package presenter;

public interface FinesPresenter {
    public void getListFines();
}
