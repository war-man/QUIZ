package presenter;

public interface TrafficSignsPresenter {
    public void getListTrafficSigns();
}
