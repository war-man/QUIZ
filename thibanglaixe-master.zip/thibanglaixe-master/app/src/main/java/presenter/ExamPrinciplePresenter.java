package presenter;

public interface ExamPrinciplePresenter {
    public void getListExamPrinciples();
}
