package ui.fragment;

public interface PrincipleTabFragment {
    public void display();
}
