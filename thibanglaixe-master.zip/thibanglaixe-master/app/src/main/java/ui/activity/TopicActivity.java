package ui.activity;

import java.util.List;

import model.Topic;

public interface TopicActivity {
    public void setListTopics(List<Topic> topics);
}
