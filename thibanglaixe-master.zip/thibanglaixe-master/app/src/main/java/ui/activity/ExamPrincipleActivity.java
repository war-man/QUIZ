package ui.activity;

import java.util.List;

import model.ExamPrinciple;

public interface ExamPrincipleActivity {
    public void setListExamPrinciples(List<ExamPrinciple> examPrinciples);
}
