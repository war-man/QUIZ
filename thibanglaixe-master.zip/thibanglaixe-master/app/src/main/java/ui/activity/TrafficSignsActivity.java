package ui.activity;

import java.util.List;

import model.TrafficSigns;

public interface TrafficSignsActivity {
    public void setListTrafficSigns(List<TrafficSigns> trafficSigns);
}
