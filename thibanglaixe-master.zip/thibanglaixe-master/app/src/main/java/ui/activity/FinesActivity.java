package ui.activity;

import java.util.List;

import model.Fines;

public interface FinesActivity {
    public void setListFines(List<Fines> fines);
}
