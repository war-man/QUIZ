package serviceCallback;

/**
 * Created by PRINCE D. TOAD on 3/27/2017.
 */

public interface InfoCallback {
    public void onSuccess(String message);

    public void onFail(String error);
}
