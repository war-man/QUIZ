package com.example.vietpc.appdethi.View.Activity.lop_dethi;

public class Chapter {
    private String title;
    private String img;

    public Chapter(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }
}
