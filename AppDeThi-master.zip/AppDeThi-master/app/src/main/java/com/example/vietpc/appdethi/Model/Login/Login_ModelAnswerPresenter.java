package com.example.vietpc.appdethi.Model.Login;

public interface Login_ModelAnswerPresenter  {
     void LoginSuccess();
     void LoginFail();
}
