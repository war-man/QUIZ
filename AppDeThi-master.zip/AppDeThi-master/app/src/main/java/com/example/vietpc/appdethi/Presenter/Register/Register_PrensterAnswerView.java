package com.example.vietpc.appdethi.Presenter.Register;

public interface Register_PrensterAnswerView {
    public void RegisterSuccess();
    public void RegisterFail_Email();
    public void RegisterFail_CaptCha();
    public void RegisterFail_MK();
    public void RegisterFail_MK1();
    public void RegisterFail_HoTen();
    public  void NoConnection();
    public  void RegisterFail_Email_Exsist();
}
