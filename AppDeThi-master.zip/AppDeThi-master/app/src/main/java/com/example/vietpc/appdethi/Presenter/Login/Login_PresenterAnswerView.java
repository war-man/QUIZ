package com.example.vietpc.appdethi.Presenter.Login;

public interface Login_PresenterAnswerView {
    void LoginSuccess();
    void LoginFail();
}
