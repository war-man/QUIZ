# QuizDemo
A simple implementation of a quiz app that parses question data from XML and stores them in SQLite database.

![Screenshot](https://cloud.githubusercontent.com/assets/6756987/6928936/3145b9a6-d7ac-11e4-9a26-12f81f1dd37c.jpg)
