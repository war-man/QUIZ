# QuizApp
An android quiz app which uses Firebase realtime database.

Created for fun.
