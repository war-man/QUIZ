package com.example.aman.quizforlab;

import java.util.List;

/**
 * Created by Aman on 10/16/2016.
 */

public interface CallbackForUI {
     void showUI(List<Question> questionArrayList);
}
