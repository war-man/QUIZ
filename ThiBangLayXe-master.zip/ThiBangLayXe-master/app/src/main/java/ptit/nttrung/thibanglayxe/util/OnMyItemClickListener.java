package ptit.nttrung.thibanglayxe.util;

/**
 * Created by TrungNguyen on 11/27/2017.
 */

public interface OnMyItemClickListener {
    void onItemClick(int position);
}