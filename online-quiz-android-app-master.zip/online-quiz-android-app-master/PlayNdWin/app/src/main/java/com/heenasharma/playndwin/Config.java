package com.heenasharma.playndwin;

/**
 * Created by heena sharma on 6/2/2017.
 */

public class Config
{
    protected static String ip="http://192.168.1.20/playNwin/";
}