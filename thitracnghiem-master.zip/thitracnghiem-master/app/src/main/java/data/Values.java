package data;

/**
 * Created by Administrator on 1/4/2018.
 */

public class Values {
    public static final String DB_HOST = "http://khcb.tvu.edu.vn/tracnghiem/api";
    public static final String RESOURCE_HOST = "http://khcb.tvu.edu.vn/tracnghiem/public/assets/images";
    public static String CURRENT_USER = "";
    public static int NUM_OF_QUESTION = 20;
    public static final String PREFS_NAME = "PrefsFile";

}
